
# variable declaration
n = 6

# actual for-loop implementation
for i in range(1, n+1):         # variable 'i' holds kung hanggang saang number yung ipriprint at the moment
    for j in range(1, i+1):     # variable 'j' holds anong value yung currently mo piniprint
        print(f"{j} ", end='')  # print the value
    print() # just add a spacer
