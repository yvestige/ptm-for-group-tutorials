
# variable declaration
n = 6

# actual while-loop implementation
current_hanggang_saan = 1
while current_hanggang_saan <= n:       # habang yung "current_hanggang_saan" not equal kay n
    current_number = 1                                   # reset current_number to 1
    while current_number <= current_hanggang_saan:       # habang yung current number is di pa yung hangganan ng dapat iprint
        print(f"{current_number} ", end='')                     # print mo lang yung number
        current_number += 1                                     # tapos update mo si current_number, add 1 syempre
    print()                                              # lagay ka lang ng spacer
    current_hanggang_saan += 1                           # tapos next na "current_hanggang_saan" na.
    
    
    
# NOTE: Take note that while the variable names might be useful here,
# it's generally better to just use simple letters like 'i' and 'j' when using
# variables kapag variables na tagacount lang and temporary like these ones.

# Reason: It's much neater tingnan. Pero if it helps na may ganung variable 
# name, it's just fine. For reference, look, mas malinis yung code sa baba:

'''
i = 1
while i <= n:
    j = 1
    while j <= i:
        print(j, end=' ')
        j += 1
    print()
    i += 1
'''